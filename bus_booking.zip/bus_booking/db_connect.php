<?php
$conn= new mysqli('localhost','root','','bus_booking')or die("Could not connect to mysql".mysqli_error($con));

?>